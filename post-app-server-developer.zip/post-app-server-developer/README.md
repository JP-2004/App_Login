
# Post-App

Aplicacion para generar post y manejo de authenticacion


## Installation

```bash
  npm install
```


## Deployment

```bash
  npm run dev
```
